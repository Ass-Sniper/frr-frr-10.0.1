# upstream packaging

## RPM-based system (Fedora, CentOS, SUSE, ...) quickstart
```
sudo dnf install -y git rpm-build python3-pip
pip3 install apkg
apkg build -i
```
See apkg docs: https://pkg.labs.nic.cz/pages/apkg/
