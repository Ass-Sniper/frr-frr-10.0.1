// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * eigrp - vrf code
 * Copyright (C) 2019 Cumulus Networks, Inc.
 *               Donald Sharp
 */
#ifndef __EIGRP_VRF_H__

extern void eigrp_vrf_init(void);
#endif
