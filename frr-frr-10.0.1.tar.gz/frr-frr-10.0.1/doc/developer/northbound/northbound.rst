.. _northbound:

**************
Northbound API
**************

.. toctree::
   :maxdepth: 2

   architecture
   transactional-cli
   retrofitting-configuration-commands
   operational-data-rpcs-and-notifications
   advanced-topics
   yang-tools
   yang-module-translator
   demos
   links
   plugins-sysrepo
   ppr-basic-test-topology
   ppr-mpls-basic-test-topology
