.. _path_internals:

*********
Internals
*********

.. toctree::
   :maxdepth: 2

   path-internals-daemon
   path-internals-pcep
