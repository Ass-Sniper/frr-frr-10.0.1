..
.. January 12 2024, Christian Hopps <chopps@labn.net>
..
.. Copyright (c) 2024, LabN Consulting, L.L.C.
..
..

Configuration for the daemon should be saved in the FRR integrated configuration
file located in |INSTALL_PREFIX_ETC|/frr.conf, see :ref:`config-file` for more
information on system configuration.

.. include:: prior-config-files.rst
