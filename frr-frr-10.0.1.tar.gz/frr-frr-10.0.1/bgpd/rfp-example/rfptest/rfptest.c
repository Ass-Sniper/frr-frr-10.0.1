// SPDX-License-Identifier: GPL-2.0-or-later
/*
 *
 * Copyright 2015-2016, LabN Consulting, L.L.C.
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/* dummy test program */
#include <stdio.h>
#include <stdlib.h>
#include "rfptest.h"
int main(void)
{
	printf("Your test code goes here.\n");
	exit(1);
}
