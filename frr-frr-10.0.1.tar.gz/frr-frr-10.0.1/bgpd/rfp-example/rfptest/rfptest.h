// SPDX-License-Identifier: GPL-2.0-or-later
/*
 *
 * Copyright 2015-2016, LabN Consulting, L.L.C.
 *
 */

/* Sample header file */
#ifndef _RFPTEST_H
#define _RFPTEST_H

#endif /* _RFPTEST_H */
