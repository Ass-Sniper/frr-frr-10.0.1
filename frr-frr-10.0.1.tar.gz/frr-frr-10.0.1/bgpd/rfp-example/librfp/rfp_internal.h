// SPDX-License-Identifier: GPL-2.0-or-later
/*
 *
 * Copyright 2015-2016, LabN Consulting, L.L.C.
 *
 */

/* Sample header file */
#ifndef _RFP_INTERNAL_H
#define _RFP_INTERNAL_H
#include "lib/zebra.h"
#include "rfp.h"
#include "bgpd/rfapi/rfapi.h"

#endif /* _RFP_INTERNAL_H */
