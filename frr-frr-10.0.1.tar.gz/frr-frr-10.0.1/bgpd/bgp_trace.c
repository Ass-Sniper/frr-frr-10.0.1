#define TRACEPOINT_CREATE_PROBES
#define TRACEPOINT_DEFINE

#include <zebra.h>

#include "bgp_trace.h"
